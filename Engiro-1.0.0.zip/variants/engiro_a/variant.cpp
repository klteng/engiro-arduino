/*
  Copyright (c) 2014-2015 Arduino LLC.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
/*
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * + Pin number +  ENGIRO-BLUE     |  PIN   | Label/Name      | Comments (* is for default peripheral in use)
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | MODBUS           |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 4          | TX ENABLE        |  PA03  | RS485 TX EN     | I/O                     
 * | 48         | DRIVER OUT       |  PB03  | RS485 OUT       | UART  SERCOM5/PAD[1]    
 * | 47         | DRIVER IN        |  PB02  | RS485 IN        | UART  SERCOM5/PAD[0]    
 * | 3          | RX ENABLE        |  PA02  | RS485 RX EN     | I/O                     
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | ANALOG 0-10V     |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 9          | VOLTAGE INPUT    |  PA04  | 0~10V INPUT     | ADC   AIN[4]            
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | CURRENT 4-20MA   |        |                 | 
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 10         | CURRENT INPUT    |  PA05  | 4~20MA INPUT    | ADC   AIN[5]            
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | DIGITAL OUTPUT   |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 8          | DO #1            |  PB09  | DIGITAL OUTPUT 1| I/O                     
 * | 7          | DO #2            |  PB08  | DIGITAL OUTPUT 2| I/O                     
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | DIGITAL INPUT    |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 39         | DI #1            |  PA27  | DIGITAL INPUT 1 | I/O                     
 * | 41         | DI #2            |  PA28  | DIGITAL INPUT 1 | I/O                     
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | POWER MONITOR    |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 11         | BATTERY VOLTAGE  |  PA06  | POWER INPUT     | ADC   AIN[6]            
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | SPI              |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 19         | SPI MOSI         |  PB10  | MOSI            | SPI   SERCOM4/PAD[2]    
 * | 20         | SPI CLK          |  PB11  | SCK             | SPI   SERCOM4/PAD[3]    
 * | 21         | SPI MISO         |  PA12  | MISO            | SPI   SERCOM4/PAD[0]    
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | LEDs             |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 25         | LED #1           |  PA16  | INDICATOR 1     | I/O                     
 * | 26         | LED #2           |  PA17  | INDICATOR 2     | I/O                     
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | USB              |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 33         | USB DATA-        |  PA24  | USB_NEGATIVE    | *USB/DM                 
 * | 34         | USB DATA+        |  PA25  | USB_POSITIVE    | *USB/DP                 
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | COM MODULE       |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 16         | IO #1            |  PA11  | DIGITAL IO 1    | I/O                     
 * | 13         | IO #2            |  PA08  | DIGITAL IO 2    | I/O                     
 * | 12         | IO #3            |  PA07  | DIGITAL IO 3    | I/O                     
 * | 14         | UART RX          |  PA09  | UART RX         | UART  SERCOM0/PAD[1]
 * | 15         | UART TX          |  PA10  | UART TX         | UART  SERCOM0/PAD[2]
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | SWD PORT         |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 45         | SWCLK            |  PA30  |                 | SWCLK, alternate use EXTINT[10] TCC1/WO[0] SERCOM1/PAD[2]
 * | 46         | SWDIO            |  PA31  |                 | SWDIO, alternate use EXTINT[11] TCC1/WO[1] SERCOM1/PAD[3]
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            |32.768KHz Crystal |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 1          | CLK INPUT        |  PA00  | XIN32           | EIC/EXTINT[0] SERCOM1/PAD[0] TCC2/WO[0]
 * | 2          | CLK OUTPUT       |  PA01  | XOUT32          | EIC/EXTINT[1] SERCOM1/PAD[1] TCC2/WO[1]
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | GROUND           |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 5          | GND              |        |                 |
 * | 18         | GND              |        |                 |
 * | 35         | GND              |        |                 |
 * | 42         | GND              |        |                 | 
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | RESET            |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 40         | RESET INPUT      |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | POWER            |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 6          | VDDANA           |        |                 |
 * | 17         | VDDIO1           |        |                 |
 * | 36         | VDDIO2           |        |                 |
 * | 44         | VDDIN            |        |                 |
 * | 43         | VDDCORE          |        |                 |  
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | UNUSED PINS      |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 38         | PB23             |        |                 |
 * | 37         | PB22             |        |                 |
 * | 20         | PB11             |        |                 |
 * | 32         | PA23             |        |                 |
 * | 31         | PA22             |        |                 |  
 * | 30         | PA21             |        |                 |
 * | 29         | PA20             |        |                 |
 * | 28         | PA19             |        |                 |
 * | 23         | PA14             |        |                 |
 * | 24         | PA15             |        |                 |  
 * | 22         | PA13             |        |                 |
 * | 27         | PA18             |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * 
 * ALL PINS ARE INDIRECT CONNECTION TO TERMINAL.
 * 
 */


#include "variant.h"

/*
 * Pins descriptions
 */
const PinDescription g_APinDescription[]=
{
  // 0..3 - Modbus
  // ----------------------
  // 0 - DIGITAL IO
  // 1 - SERCOM/UART (Serial0)
  // 2 - SERCOM/UART (Serial0)
  // 3 - DIGITAL IO
  { PORTA,  3, PIO_OUTPUT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },   // RS485 TX ENABLE
  { PORTB,  3, PIO_SERCOM_ALT, PIN_ATTR_NONE, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },  // TX: SERCOM5/PAD[1]
  { PORTB,  2, PIO_SERCOM_ALT, PIN_ATTR_NONE, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },  // RX: SERCOM5/PAD[0]
  { PORTA,  2, PIO_OUTPUT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },   // RS485 RX ENABLE  

  // 4 - ANALOG 0~10V
  { PORTA,  4, PIO_ANALOG, 0, ADC_Channel4, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },                    // ADC/AIN[4]  

  // 5 - CURRENT 4~20MA
  { PORTA,  5, PIO_ANALOG, 0, ADC_Channel5, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },                    // ADC/AIN[5]  

  // 6..7 - DIGITAL OUTPUT
  { PORTB,  9, PIO_OUTPUT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },   // DIGITAL OUTPUT #1
  { PORTB,  8, PIO_OUTPUT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },   // DIGITAL OUTPUT #2

  // 8..9 - DIGITAL INPUT
  { PORTA, 27, PIO_INPUT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_15 },      // DIGITAL INPUT #1/EXT[15]
  { PORTA, 28, PIO_INPUT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_8 },       // DIGITAL INPUT #2/EXT[8]

  // 10 - POWER MONITOR
  { PORTA,  6, PIO_ANALOG, 0, ADC_Channel6, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },                    // ADC/AIN[6]  

  // 11..13 - SPI
  { PORTB, 10, PIO_SERCOM_ALT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_10 }, // MOSI: SERCOM4/PAD[2]/EXT[10]
  { PORTB, 11, PIO_SERCOM_ALT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_11 }, // SCK: SERCOM4/PAD[3]/EXT[11]
  { PORTA, 12, PIO_SERCOM_ALT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_12 }, // MISO: SERCOM4/PAD[0]/EXT[12]

  // 14..15 - LED
  { PORTA, 16, PIO_OUTPUT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },   // LED #1  
  { PORTA, 17, PIO_PWM, (PIN_ATTR_DIGITAL|PIN_ATTR_PWM|PIN_ATTR_TIMER), No_ADC_Channel, PWM2_CH1, TCC2_CH1, EXTERNAL_INT_NONE },   // LED #2

  // 16..20 - COMM MODULE
  // 16 - DIGITAL IO
  // 17 - DIGITAL IO
  // 18 - DIGITAL IO
  // 19 - UART (Serial1)
  // 20 - UART (Serial1)
  { PORTA, 11, PIO_OUTPUT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_11 },     // IO #1/EXT[11]
  { PORTA,  8, PIO_OUTPUT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },   // IO #2
  { PORTA,  7, PIO_OUTPUT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_7 },      // IO #3/EXT[7]
  { PORTA,  9, PIO_SERCOM, PIN_ATTR_NONE, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },      // RX: SERCOM0/PAD[1]
  { PORTA, 10, PIO_SERCOM, PIN_ATTR_NONE, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },      // TX: SERCOM0/PAD[2]
} ;

extern "C" {
    unsigned int PINCOUNT_fn() {
        return (sizeof(g_APinDescription) / sizeof(g_APinDescription[0]));
    }
}

const void* g_apTCInstances[TCC_INST_NUM+TC_INST_NUM]={ TCC0, TCC1, TCC2, TC3, TC4, TC5 } ;

// Multi-serial objects instantiation
SERCOM sercom0( SERCOM0 ) ;
SERCOM sercom1( SERCOM1 ) ;
SERCOM sercom2( SERCOM2 ) ;
SERCOM sercom3( SERCOM3 ) ;
SERCOM sercom4( SERCOM4 ) ;
SERCOM sercom5( SERCOM5 ) ;

Uart Serial1( &sercom0, PIN_SERIAL1_RX, PIN_SERIAL1_TX, PAD_SERIAL1_RX, PAD_SERIAL1_TX ) ;
Uart Serial0( &sercom5, PIN_SERIAL0_RX, PIN_SERIAL0_TX, PAD_SERIAL0_RX, PAD_SERIAL0_TX ) ;

void SERCOM0_Handler()
{
  Serial1.IrqHandler();     // Communication Module
}

void SERCOM5_Handler()
{
  Serial0.IrqHandler();     // RS485
}

