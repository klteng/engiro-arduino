/*
  Copyright (c) 2014-2015 Arduino LLC.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
/*
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * + Pin number +  ZERO Board pin  |  PIN   | Label/Name      | Comments (* is for default peripheral in use)
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | Digital          |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 0          | TX_ENABLE        |  PA03  | TXEN            | RS485 TRANSMITTER ENABLE
 * | 1          | RS485 OUT        |  PB03  | RS485_OUT       | TRANSMIT (USE SOFTSERIAL)
 * | 2          | RS485 IN         |  PB02  | RS485_IN        | RECEIVE (USE SOFTSERIAL)
 * | 3          | RX_ENABLE        |  PA02  | RXEN            | RS485 RECEIVER ENABLE
 * | 4          | DIGITAL OUTPUT 1 |  PB09  | ISO_OUT1        | ISOLATED DIGITAL OUTPUT 1
 * | 5          | DIGITAL OUTPUT 2 |  PB08  | ISO_OUT2        | ISOLATED DIGITAL OUTPUT 2
 * | 6          | DIGITAL INPUT 1  |  PA27  | ISO_IN1         | ISOLATED DIGITAL INPUT 1
 * | 7          | DIGITAL INPUT 2  |  PA28  | ISO_IN2         | ISOLATED DIGITAL INPUT 2
 * | 8          | EXT MODULE IO 1  |  PA11  | EXT_IO1         | EXTERNAL MODULE IO 1
 * | 9          | EXT MODULE IO 2  |  PA08  | EXT_IO2         | EXTERNAL MODULE IO 2
 * | 10         | EXT MODULE IO 3  |  PA07  | EXT_IO3         | EXTERNAL MODULE IO 3
 * | 11         | EXT MODULE RX    |  PA09  | EXT_UART_RX     | UART RX (USE SOFTSERIAL)
 * | 12         | EXT MODULE TX    |  PA10  | EXT_UART_TX     | UART TX (USE SOFTSERIAL)
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | Analog           |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 13         | ANALOG 0~10V     |  PA04  | ANA_VOLTAGE     | ANALOG VOLTAGE SAMPLING 0~10V     ADC/AIN[4]
 * | 14         | CURRENT 4~20MA   |  PA05  | ANA_CURRENT     | ANALOG CURRENT SAMPLING 4~20MA    ADC/AIN[5]
 * | 15         | POWER MONITOR    |  PA06  | ANA_BATTERY     | BOARD VOLTAGE INPUT READING       ADC/AIN[6]
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | SPI (Legacy ICSP) |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 16         | SPI MISO         |  PA12  | MISO            | EIC/EXTINT[12] SERCOM2/PAD[0] *SERCOM4/PAD[0] TCC2/WO[0] TCC0/WO[6]
 * | 17         | SPI MOSI         |  PB10  | MOSI            | EIC/EXTINT[10]                *SERCOM4/PAD[2] TC5/WO[0]  TCC0/WO[4]
 * | 18         | SPI CLOCK        |  PB11  | SCK             | EIC/EXTINT[11]                *SERCOM4/PAD[3] TC5/WO[1]  TCC0/WO[5]
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | LEDs             |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 19         | LED 1            |  PA16  | LED_1           | LED INDICATOR 1
 * | 20         | LED 2            |  PA17  | LED_2           | LED INDICATOR 2
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * |            | USB              |        |                 |
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 * | 21         |                  |  PA24  | USB_NEGATIVE    | *USB/DM
 * | 22         |                  |  PA25  | USB_POSITIVE    | *USB/DP
 * +------------+------------------+--------+-----------------+--------------------------------------------------------------------------------------------------------
 */


#include "variant.h"

/*
 * Pins descriptions
 */
const PinDescription g_APinDescription[]=
{
  // 0..12 - Digital pins
  // ----------------------
  { PORTA,  3, PIO_OUTPUT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },   // RS485 TX ENABLE
  { PORTB,  3, PIO_INPUT, PIN_ATTR_NONE, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },       // TX: SOFTSERIAL/EXT[3] *** Temporary change to input
  { PORTB,  2, PIO_INPUT, PIN_ATTR_NONE, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },       // RX: SOFTSERIAL/EXT[2] *** Temporary change to input
  { PORTA,  2, PIO_OUTPUT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },   // RS485 RX ENABLE  
  { PORTB,  9, PIO_OUTPUT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },   // DIGITAL OUTPUT #1
  { PORTB,  8, PIO_OUTPUT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },   // DIGITAL OUTPUT #2
  { PORTA, 27, PIO_INPUT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_15 },      // DIGITAL INPUT #1/EXT[15]
  { PORTA, 28, PIO_INPUT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_8 },       // DIGITAL INPUT #2/EXT[8]
  { PORTA, 11, PIO_OUTPUT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_11 },     // IO #1/EXT[11]
  { PORTA,  8, PIO_OUTPUT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },   // IO #2
  { PORTA,  7, PIO_OUTPUT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_7 },      // IO #3/EXT[7]
  { PORTA,  9, PIO_INPUT, PIN_ATTR_NONE, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_9 },          // RX: SOFTSERIAL/EXT[9]
  { PORTA, 10, PIO_OUTPUT, PIN_ATTR_NONE, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_10 },        // TX: SOFTSERIAL/EXT[10]

  // 13..15 - Analog pins
  // --------------------
  { PORTA,  4, PIO_ANALOG, PIN_ATTR_ANALOG, ADC_Channel4, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },      // ADC/AIN[4]
  { PORTA,  5, PIO_ANALOG, PIN_ATTR_ANALOG, ADC_Channel5, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },      // ADC/AIN[5]
  { PORTA,  6, PIO_ANALOG, PIN_ATTR_ANALOG, ADC_Channel6, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },      // ADC/AIN[6]

  // 16..18 - SPI pins (ICSP:MISO,SCK,MOSI)
  // ----------------------
  { PORTA, 12, PIO_SERCOM_ALT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_12 }, // MISO: SERCOM4/PAD[0]
  { PORTB, 10, PIO_SERCOM_ALT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_10 }, // MOSI: SERCOM4/PAD[2]
  { PORTB, 11, PIO_SERCOM_ALT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_11 }, // SCK: SERCOM4/PAD[3]

  // 19..20 - LEDS
  // --------------------
  { PORTA, 16, PIO_OUTPUT, PIN_ATTR_DIGITAL, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE },   // LED #1  
  { PORTA, 17, PIO_PWM, (PIN_ATTR_DIGITAL|PIN_ATTR_PWM|PIN_ATTR_TIMER), No_ADC_Channel, PWM2_CH1, TCC2_CH1, EXTERNAL_INT_NONE },   // LED #2

  // 21..22 - UART
  // ----------------------
  // 0/1 - SERCOM/UART (Serial1)
  { PORTA,  9, PIO_SERCOM, (PIN_ATTR_DIGITAL), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_9 },    // RX: SERCOM0/PAD[1]
  { PORTA, 10, PIO_SERCOM, (PIN_ATTR_DIGITAL), No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_10 },   // TX: SERCOM0/PAD[2]

  // 23..24 - USB
  // --------------------
  { PORTA, 24, PIO_COM, PIN_ATTR_NONE, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // USB/DM
  { PORTA, 25, PIO_COM, PIN_ATTR_NONE, No_ADC_Channel, NOT_ON_PWM, NOT_ON_TIMER, EXTERNAL_INT_NONE }, // USB/DP
} ;

extern "C" {
    unsigned int PINCOUNT_fn() {
        return (sizeof(g_APinDescription) / sizeof(g_APinDescription[0]));
    }
}

const void* g_apTCInstances[TCC_INST_NUM+TC_INST_NUM]={ TCC0, TCC1, TCC2, TC3, TC4, TC5 } ;

// Multi-serial objects instantiation
SERCOM sercom0( SERCOM0 ) ;
SERCOM sercom1( SERCOM1 ) ;
SERCOM sercom2( SERCOM2 ) ;
SERCOM sercom3( SERCOM3 ) ;
SERCOM sercom4( SERCOM4 ) ;
SERCOM sercom5( SERCOM5 ) ;


Uart Serial1( &sercom0, PIN_SERIAL1_RX, PIN_SERIAL1_TX, PAD_SERIAL1_RX, PAD_SERIAL1_TX ) ;
void SERCOM0_Handler()
{
  Serial1.IrqHandler();
}

/*
Uart Serial( &sercom5, PIN_SERIAL_RX, PIN_SERIAL_TX, PAD_SERIAL_RX, PAD_SERIAL_TX ) ;
void SERCOM5_Handler()
{
  Serial.IrqHandler();
}
*/

